"""
Provides cowrie version information.
"""

# This file is auto-generated! Do not edit!
# Use `python -m incremental.update cowrie` to change this file.

from __future__ import annotations

from incremental import Version

__version__ = Version("cowrie", 2, 5, 0)
__all__: list[str] = ["__version__"]
